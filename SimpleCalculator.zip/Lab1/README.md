# Lab1
Lab1 for SEG2105-F2021
